package fr.esisar.cookbotStatePatern;

public class CookBotStatePaternTestDrive {
	
	public static void main(String[] args) {
		CookBot cookBot = new CookBot();
		cookBot.switchOn();
		cookBot.regularCook();
		cookBot.switchOff();

		cookBot.switchOn();
		cookBot.switchOff();
		cookBot.slowCook();
	}
	
}