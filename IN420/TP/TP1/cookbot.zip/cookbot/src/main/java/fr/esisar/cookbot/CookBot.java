package fr.esisar.cookbot;

public class CookBot {
	
	static final int ON = 0;
	static final int OFF = 1;
	static final int COOK = 2;
	
	private int state;

	public CookBot() {
		super();
		state = ON;
	}
	
	public void switchOn() {
		if (state == ON) {
			System.out.println("CookBot is already switched on");
		} else if (state == COOK) {
			state = ON;
			System.out.println("CookBot is switched on...");
		} else if (state == OFF) {
			state = ON;
			System.out.println("CookBot is switched on...");
		}
	}
	
	public void regularCook() {
		if (state == ON) {
			state = COOK;
			System.out.println("CookBot is cooking...");
		} else if (state == COOK) {
			System.out.println("CookBot is already cooking...");
		} else if (state == OFF) {
			System.out.println("CookBot cannot cook when it is switched off");
		}
	}
	
	public void switchOff() {
		if (state == ON) {
			state = OFF;
			System.out.println("CookBot is switched off");
		} else if (state == COOK) {
			System.out.println("CookBot cannot be switched off while cooking");
		} else if (state == OFF) {
			System.out.println("CookBot is already switched off");
		}
	}

	public int getState() {
		return state;
	}
}
